#include <util/atomic.h> // For the ATOMIC_BLOCK macro


#define ENCODER_PIN_A 2
#define ENCODER_PIN_B 3


long readEncoder();
void resetEncoder();
void resetEncoders();

