
long readEncoder(int i);
void resetEncoder(int i);
void resetEncoders();

